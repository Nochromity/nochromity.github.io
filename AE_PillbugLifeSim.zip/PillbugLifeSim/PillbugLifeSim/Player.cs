﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace PillbugLifeSim
{
    internal class Player
    {
        // Attributes
        private int Hunger = 50; // Max of 100, lose 1 hp for every turn spent at 0. Passive degrade = 2
        private int Thirst = 30; // Max of 80, lose 1 hp for every turn spent at 0. Passive degrade = 2
        public int Age = 0; // Game ends if Age reaches 50(?) [Enter Hibernation] (For prototype, max age is 5)
        public int HitPoints = 5; // Max of 5, dead if 0
        private int Energy = 15; // Day system: When Sleep, reset Energy to 10 and add 1 to Age. Restore 2 HitPoints if applicable
        private bool IsCurled = false;
        private int NearFood = 0;
        private int NearWater = 1;
        private int DistanceFromHome = 0;
        private string Location = "Home";

        public Player()
        {

        }

        Environment Home = new Environment(0, 1, true);

        Environment Field = new Environment(1, 3, true);

        Environment UnderTree = new Environment(5, 1, true);

        Environment Sidewalk = new Environment(0, 0, false);

        Environment Garden = new Environment(6, 8, true);

        Environment Fence = new Environment(2, 1, true);

        public void Action()
        {
            var input = ReadLine();
            switch (input.ToLower())
            {
                    case "eat":
                        Eat();
                        break;
                    case "drink":
                        Drink();
                        break;
                    case "dig":
                        Dig();
                        break;
                    case "sleep":
                        Sleep();
                        break;
                    case "explore":
                        Explore();
                        break;
                    case "go home":
                        GoHome();
                        break;
                    case "play":
                        Play();
                        break;
                    case "roll up":
                        CurlUp();
                        break;
                    case "unroll":
                        Uncurl();
                        break;
                    case "wait":
                        Wait();
                        break;
                    case "help":
                        Help();
                        break;
                    case "die":
                        Die();
                        break;
                    default:
                        WriteLine("Unrecognized command. Perhaps you could try to find something to eat or drink?\n(Type 'help' for a list of functional commands!)");
                        break;
            } 
        }

        // Actions
        private void Help()
        {
            WriteLine("Current functioning commands: Eat, Drink, Dig, Sleep, Explore, Go Home, Play" +
                "\nCommands that work, but don't do anything useful yet: Roll up, Unroll, Wait");
        }

        private string curledError = "You can't do that when rolled up.";
   
        private void Eat()
        {
            if (IsCurled == true) { WriteLine(curledError); }
            else if (Hunger == 100) { WriteLine("You're so full, you don't think you can eat another bite..."); }
            else if (NearFood >= 1)
            {
                WriteLine("You munch on some tasty leaf litter. It makes you feel much better.");
                Energy--;
                Hunger += 20;
                Thirst -= 2;
                NearFood--;
            }
            else if (NearFood < 1 && Hunger >= 60) { WriteLine("There's nothing to eat here, but you aren't too hungry right now."); }
            else { WriteLine("There's no food to eat! Maybe it's time to go find some?"); }
        }
        private void Drink()
        {
            if (IsCurled == true) { WriteLine(curledError); }
            else if (Thirst == 80) { WriteLine("Your thirst is slaked, for now."); }
            else if (NearWater == 1)
            {
                WriteLine("There's not much to drink here, but you manage to scrounge up some moisture.");
                Energy--;
                Thirst += 10;
                NearWater--;
                Hunger -= 2;
            }
            else if (NearWater >= 2)
            {
                Energy--;
                WriteLine("You happily slurp up the water you found.");
                Thirst += 20;
                NearWater -= 2;
                Hunger -= 2;
            }
            else if (NearWater < 1 && Thirst >= 60) { WriteLine("There doesn't seem to be any water around, but you aren't particularly thirsty."); }
            else { WriteLine("There's no water around! It would probably be a good idea to find some."); }
        }
        private void Dig()
        {
            if (IsCurled == true) { WriteLine(curledError); }
            else if (Location == "Sidewalk") { WriteLine("The ground is too hard to dig here!"); }
            else
            {
                Energy--;
                WriteLine("You dig through the soft earth...");
                // TO DO: Environmental moisture variable
                WriteLine("You found some water!");
                NearWater++;
                Thirst -= 2;
                Hunger -= 2;
            }
        }
        private void Sleep()
        {
            if (Energy >= 12) { WriteLine("Aw, but the night has only just begun! You should probably at least find something to eat or " +
                "\ndrink before you go back to sleep."); }
            else if (Energy < 12 && DistanceFromHome == 0)
            {
                WriteLine("You curl up cozy and safe in your den and drift to sleep..." +
                    "\n...\n...\n");
                Energy = 15;
                Age++;
                Thirst -= 20;
                Hunger -= 20;
                if (HitPoints == 4) { HitPoints++; }
                else if (HitPoints < 4) { HitPoints += 2; }
                Clock.Day++;
                Clock.Time = -1;
                WriteLine("Press enter to continue.");
                ReadLine();
                Clear();
                WriteLine("...\nYou wake up as the sun drifts lower in the sky, its uncomfortable heat receding into something softer." +
                    "\nHow would you like to start your night?");
            }
            else
            {
                WriteLine("You aren't at home! It might not be safe to sleep here. Are you sure?");
                void ForceSleepQuery()
                {
                    switch (ReadLine().ToLower())
                    {
                        case "yes":
                            ForceSleep();
                            break;
                        case "no":
                            WriteLine("Alright, then.");
                            break;
                        default:
                            WriteLine("Please type yes or no.");
                            ForceSleepQuery();
                            break;
                    }
                }
                ForceSleepQuery();
            }
        }
        private void ForceSleep()
        {
            // TO DO: ForceSleep. Used if player tries to sleep outside of Home, or passes out from exhaustion
            // Random chance of waking up to an ant nibbling on your shell, -1 hp, or a larger bug, -2 hp, or a bird pecking at you, -4 hp
            // May not restore Energy to full
            // Costs more thirst than regular Sleep (unless Rain)
            WriteLine("You curl up out in the open and fall into an uncertain slumber..." +
                "\n...\n...\n");
            Energy = 15;
            Age++;
            Thirst -= 30;
            Hunger -= 20;
            if (HitPoints <= 4) { HitPoints++; }
            Clock.Day++;
            Clock.Time = -1;
            WriteLine("Press enter to continue.");
            ReadLine();
            Clear();
            WriteLine("...\nYou wake up as the sun drifts lower in the sky, its uncomfortable heat receding into something softer." +
                "\nHow would you like to start your night?");
        }
        private void Explore()
        {
            if (IsCurled == true) { WriteLine(curledError); }
            else if (Location == "Home")
            {
                WriteLine("You crawl out from under your log into the cool evening air...");
                Energy--;
                Hunger -= 2;
                Thirst -= 2;
                DistanceFromHome = 1;
                Location = "Field";
                WriteLine("You are now in the Field!");
                NearFood = Field.HasFood;
                NearWater = Field.HasWater;
                WriteLine("There's not much in this area, but there's a dead leaf scrap or two you could eat, and plenty of space to dig." +
                    "\nFrom here, you can see the broad shadow of the nearby tree, and the hard stone path that the giants use.");
                // WriteLine("There's not much around, but you can see some dead leaves a little further away." +
                   // "\nMaybe you should keep exploring?");
            }
            else if (Location == "Field")
            {
                WriteLine("Would you like to go to the Tree, or the Path?");
                void ChooseArea()
                {
                    switch (ReadLine().ToLower())
                    {
                        case "tree":
                            WriteLine("You wander into the shade...");
                            Energy--;
                            Hunger -= 2;
                            Thirst -= 2;
                            DistanceFromHome = 2;
                            Location = "Under Tree";
                            WriteLine("You are now under the Tree!");
                            NearFood = UnderTree.HasFood;
                            NearWater = UnderTree.HasWater;
                            WriteLine("The soft ground is dappled with moonlight, filtered through new leaves far above. Food is plentiful." +
                                "\nPast the tree, there is a fence that looms high. The wide field of grass stretches on behind you.");
                            break;
                        case "path":
                            WriteLine("You toddle onto the cold, flat stone...");
                            Energy--;
                            Hunger -= 2;
                            Thirst -= 2;
                            DistanceFromHome = 2;
                            Location = "Sidewalk";
                            WriteLine("You are now on the Path!");
                            NearFood = Sidewalk.HasFood;
                            NearWater = Sidewalk.HasWater;
                            WriteLine("There is hardly anything here. The open surface allows you to travel quickly across it, at least." +
                                "\nIn front of you, only a short ways off now, there is a garden. Many pillbugs make their homes there.");
                            break;
                        default:
                            WriteLine("Please type \"Tree\" or \"Path.\"");
                            ChooseArea();
                            break;
                    }
                }
                ChooseArea();
                //WriteLine("You walk a little further. Up close, those leaves smell delicious. The perfect amount of damp and rotting.");
                //Energy--;
                //Hunger -= 2;
                //Thirst -= 2;
                //DistanceFromHome++;
                //NearFood += 3;
            }
            else if (Location == "Under Tree")
            {
                WriteLine("Will you go to the Fence, or back to the Field?");
                void ChooseArea()
                {
                    switch (ReadLine().ToLower())
                    {
                        case "fence":
                            WriteLine("You approach the looming planks of wood...");
                            Energy--;
                            Hunger -= 2;
                            Thirst -= 2;
                            DistanceFromHome = 3;
                            Location = "Fence";
                            WriteLine("You are now at the Fence!");
                            NearFood = Fence.HasFood;
                            NearWater = Fence.HasWater;
                            WriteLine("It's very dark here, in the shadow of the fence. The ground is dry, and you think you can see webs in the corners." +
                                "\nYou cannot go any further past the fence. Too far from home. From here, you can go back to the tree.");
                            break;
                        case "field":
                            WriteLine("You move back into the tall stalks of grass...");
                            Energy--;
                            Hunger -= 2;
                            Thirst -= 2;
                            DistanceFromHome = 1;
                            Location = "Field";
                            WriteLine("You are now in the Field!");
                            NearFood = Field.HasFood;
                            NearWater = Field.HasWater;
                            WriteLine("There's not much in this area, but there's a dead leaf scrap or two you could eat, and plenty of space to dig." +
                                "\nFrom here, you can see the broad shadow of the nearby tree, the giant's path, and the log you call home.");
                            break;
                        default:
                            WriteLine("Please type \"Fence\" or \"Field.\"");
                            ChooseArea();
                            break;
                    }
                }
                ChooseArea();
            }
            else if (Location == "Sidewalk")
            {
                WriteLine("Do you continue to the Garden, or retreat to the Field?");
                void ChooseArea()
                {
                    switch (ReadLine().ToLower())
                    {
                        case "garden":
                            WriteLine("You scuttle into the safety of the leaves...");
                            Energy--;
                            Hunger -= 2;
                            Thirst -= 2;
                            DistanceFromHome = 3;
                            Location = "Garden";
                            WriteLine("You are now at the Garden!");
                            NearFood = Garden.HasFood;
                            NearWater = Garden.HasWater;
                            WriteLine("The bushes and flowers are lush, numerous other pillbugs milling about in their shade. The mulch is fresh and damp." +
                                "\nThe wall of the giants' abode blocks any further exploration in this direction. Their barren path lies behind you.");
                            break;
                        case "field":
                            WriteLine("You move back into the tall stalks of grass...");
                            Energy--;
                            Hunger -= 2;
                            Thirst -= 2;
                            DistanceFromHome = 1;
                            Location = "Field";
                            WriteLine("You are now in the Field!");
                            NearFood = Field.HasFood;
                            NearWater = Field.HasWater;
                            WriteLine("There's not much in this area, but there's a dead leaf scrap or two you could eat, and plenty of space to dig." +
                                "\nFrom here, you can see the broad shadow of the nearby tree, the giant's path, and the log you call home.");
                            break;
                        default:
                            WriteLine("Please type \"Garden\" or \"Field.\"");
                            ChooseArea();
                            break;
                    }
                }
                ChooseArea();
            }
            else { WriteLine("You've gone very far today. It would probably be a good idea to head home."); }
        }
        private void GoHome()
        {
            if (IsCurled == true) { WriteLine(curledError); }
            else if (DistanceFromHome > 0)
            {
                WriteLine("You totter your way back to the safety of your den.");
                Energy -= DistanceFromHome;
                Hunger -= DistanceFromHome*2;
                Thirst -= DistanceFromHome*2;
                DistanceFromHome = 0;
                Location = "Home";
                NearFood = Home.HasFood;
                NearWater = Home.HasWater;
            }
            else { WriteLine("You're already at home!"); }
        }
        private void Play()
        {
            if (IsCurled == true) { WriteLine(curledError); }
            else if (Location == "Garden" && Hunger < 10) { WriteLine("You're too hungry to play right now! You should really eat."); }
            else if (Location == "Garden" && Thirst < 10) { WriteLine("You're too thirsty to play right now! You need to drink."); }
            else if (Location == "Garden")
            {
                WriteLine("You crawl over, brush against, nibble at and cuddle the other pill bugs, having a delightful time.");
                Energy--;
                Hunger -= 2;
                Thirst -= 2;
            }
            else { WriteLine("You are a very busy roly poly, and unfortunately do not have the time or reason to play at the moment."); }
        }
        private void CurlUp()
        {
            if (IsCurled == false)
            {
                WriteLine("You curl into a ball. You feel more secure.");
                IsCurled = true;
            }
            else { WriteLine("You're already rolled up. You'll have to uncurl to do anything else."); }
        }
        private void Uncurl()
        {
            if (IsCurled == true)
            {
                WriteLine("You uncurl from your ball. You're ready to move!");
                IsCurled = false;
            }
            else { WriteLine("But you're already uncurled?"); }
        }
        private void Wait()
        {
            WriteLine("You wait patiently, letting time pass by.");
            //Energy--; // TO DO: Change this to a time increment, once the Environment time system is set up
            Hunger -= 2;
            Thirst -= 2;
        }
        private void Die() // For testing purposes
        {
            HitPoints = 0;
        }

        // Checks
        public void ResetStats()
        {
            Hunger = 50;
            Thirst = 25;
            Age = 0;
            HitPoints = 5;
            Energy = 15;
            IsCurled = false;
            NearFood = 0;
            NearWater = 1;
            DistanceFromHome = 0;
    }
        public void RunChecks()
        {
            LifeCheck();
            if (HitPoints > 0)
            {
                HungerCheck();
                ThirstCheck();
                EnergyCheck();
            }
        }
        private void LifeCheck()
        {
            if (HitPoints == 0)
            {
                ForegroundColor = ConsoleColor.Red;
                WriteLine("Oh no, you died! :(");
                ResetColor();
                WriteLine("Press any key to continue.");
                ReadKey();
            }
        }
        private void HungerCheck()
        {
            ForegroundColor = ConsoleColor.Green;
            if (Hunger < 0) { Hunger = 0; }
            if (Hunger > 100) { Hunger = 100; }
            if (Hunger == 0)
            {
                WriteLine("You're STARVING! If you don't get food soon, you could die!");
                HitPoints--;
            }
            else if (Hunger <= 10) { WriteLine("You feel awfully hungry."); }
            else if (Hunger <= 20) { WriteLine("You're getting rather peckish."); }
            ResetColor();
        }
        private void ThirstCheck()
        {
            ForegroundColor = ConsoleColor.Blue;
            if (Thirst < 0) { Thirst = 0; }
            if (Thirst > 80) { Thirst = 80; }
            if (Thirst == 0)
            {
                WriteLine("You're dehydrated! If you don't drink water soon, you could die!");
                HitPoints--;
            }
            else if (Thirst <= 10) { WriteLine("You feel very parched."); }
            else if (Thirst <= 20) { WriteLine("You're getting pretty thirsty."); }
            ResetColor();
        }
        private void EnergyCheck()
        {
            ForegroundColor = ConsoleColor.Yellow;
            if (Energy == 10) { WriteLine("The moon is high in the sky."); }
            if (Energy == 5) { WriteLine("You're starting to get a little tired."); }
            if (Energy == 2) { WriteLine("Hints of sunlight are beginning to peek over the horizon. You should probably get to bed."); }
            ResetColor();
            if (Energy <= 0)
            {
                ForegroundColor = ConsoleColor.DarkYellow;
                WriteLine("You're too exhausted to move!");
                ResetColor();
                if (DistanceFromHome == 0) { Sleep(); }
                else { ForceSleep(); }
            }
        }
    }
}
