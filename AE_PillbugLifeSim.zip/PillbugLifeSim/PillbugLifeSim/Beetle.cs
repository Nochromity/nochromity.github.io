﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PillbugLifeSim
{
    internal class Beetle:Bug
    {
        // Attributes

        public Beetle()
            : base("Beetle", 7, 10, false, 0)
        {

        }
    }
}
