﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PillbugLifeSim
{
    internal class Clock
    {
        public static int Time = 0;
        public static int Day = 0;
        private string Weather;
    }
}
