﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PillbugLifeSim
{
    internal class Ant:Bug
    {
        //Attributes

        public Ant()
            : base("Ant", 3, 10, false, 0)
        {

        }

        private void Investigate()
        {

        }
        private void Bite()
        {

        }
        private void GoHome()
        {

        }
    }
}
