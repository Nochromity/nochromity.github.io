﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace PillbugLifeSim
{
    internal class Environment
    {
        // Attributes
        private string Weather;
        public int HasFood;
        public int HasWater;
        public bool CanDig;

        public Environment() { }
        public Environment(int foodQty, int waterQty, bool canDig)
        {
            HasFood = foodQty;
            HasWater = waterQty;
            CanDig = canDig;
        }
        // Make Environment called Home
        // Make Rain event to set NearWater to 100
        // Add some flavor text to display about surroundings every 3-5 turns (ie "A honeybee flies overhead")
        // Make the passage of time a public method, use (some of) the if/else statements currently used for energy

        // Methods
        private void Rain()
        {
            // TO DO: WaterQty constantly increases for all areas the day that it rains, and then decreases over time to normal the following day
            Weather = "Rain";
            while (Clock.Day == 3) { }
        }

        Ant ant1 = new Ant();
    }
}
