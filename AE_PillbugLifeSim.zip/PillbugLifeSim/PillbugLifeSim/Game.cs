﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace PillbugLifeSim
{
    internal class Game
    {
        // Attributes
        public bool WinConditionMet = false;
        public bool LoseConditionMet = false;

        public Game()
        {
            // Constructor
            WriteLine("Welcome to Roly Poly Survival Simulator! Are you ready to begin your life as a pill bug?");
            WriteLine("Press enter to continue...");
            ReadLine();
            Clear();
            StartGame();
        }

        Player player1 = new Player();
        private string spacer = "--------------------";

        private void StartGame()
        {
            WriteLine("It's the start of spring. Warmth reaches your shell, stirring you from your hibernation. You twitch, then uncurl, " +
                "\nallowing the dim evening light into your eyes. You get to your feet to see the familar damp earth and rotting wood " +
                "\nceiling of your den.");
            WriteLine("What would you like to do?");
            // Open-ended
            // Specific responses for recognized actions
            // If user enters unrecognized action, provide suggested actions
            // Starting action ideas: Eat, Drink, Dig, Explore, Hunt (joke response), Sleep (joke response)
            // TO DO: Put the loop in the game class (as TurnLoop), and have the action input/result be its own method
            // while (LoseConditionMet == false) loop through other checks and call action method
            // Make each check its own method to be called? Make each check a method called within a public method named CheckLoop?
            GameLoop();
            Clear();
            EndGame();
        }
        
        private void EndGame()
        {
            WriteLine("You have reached the end of the current version of the game." +
                "\nWould you like to play again?");
            switch (ReadLine().ToLower())
            {
                case "yes":
                    RestartGame();
                    break;
                case "yep":
                    RestartGame();
                    break;
                case "yeah":
                    RestartGame();
                    break;
                case "yea":
                    RestartGame();
                    break;
                case "ye":
                    RestartGame();
                    break;
                case "sure":
                    RestartGame();
                    break;
                default:
                    WriteLine("Alright, hope you enjoyed! Bye!\nPress any key to exit.");
                    break;
            }
        }

        private void GameLoop()
        {
            while (LoseConditionMet == false && WinConditionMet == false)
            {
                player1.Action();
                Clock.Time++;
                //WriteLine($"Current time: {Clock.Time}");
                WriteLine(spacer);
                player1.RunChecks();
                if (player1.HitPoints == 0) { LoseConditionMet = true; }
                else if (player1.Age == 6) { WinConditionMet = true; }
            }
        }
        private void RestartGame()
        {
            WinConditionMet = false;
            LoseConditionMet = false;
            player1.ResetStats();
            Clear();
            StartGame();
        }
    }
}
