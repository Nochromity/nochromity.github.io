﻿namespace PillbugLifeSim
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Roly Poly Survival Simulator";
            new Game();
            Console.ReadKey();
        }
    }
}