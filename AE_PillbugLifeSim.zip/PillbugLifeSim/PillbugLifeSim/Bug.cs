﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PillbugLifeSim
{
    internal class Bug
    {
        // Attributes
        protected string Species;
        protected int HitPoints;
        protected int Hunger;
        protected bool IsAggressive;
        protected int InterestInPlayer;

        public Bug(string species, int hp, int hunger, bool isAggressive, int interest)
        {
            Species = species;
            HitPoints = hp;
            Hunger = hunger;
            IsAggressive = isAggressive;
            InterestInPlayer = interest;
        }

        protected void Eat()
        {
            Hunger++;
        }
        protected void Move()
        {

        }
    }
}
